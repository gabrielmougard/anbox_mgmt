--
-- PostgreSQL database dump
--

-- Dumped from database version 9.3.4
-- Dumped by pg_dump version 12.12 (Ubuntu 12.12-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


SET default_tablespace = '';

--
-- Name: games; Type: TABLE; Schema: public; Owner: anboxcloud
--

CREATE TABLE public.games (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    url text,
    age_rating integer NOT NULL,
    publisher text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.games OWNER TO anboxcloud;

--
-- Name: games_id_seq; Type: SEQUENCE; Schema: public; Owner: anboxcloud
--

CREATE SEQUENCE public.games_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.games_id_seq OWNER TO anboxcloud;

--
-- Name: games_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: anboxcloud
--

ALTER SEQUENCE public.games_id_seq OWNED BY public.games.id;


--
-- Name: metadata; Type: TABLE; Schema: public; Owner: anboxcloud
--

CREATE TABLE public.metadata (
    id integer NOT NULL,
    player_id integer NOT NULL,
    played_game_id integer NOT NULL,
    play_time integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.metadata OWNER TO anboxcloud;

--
-- Name: metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: anboxcloud
--

CREATE SEQUENCE public.metadata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.metadata_id_seq OWNER TO anboxcloud;

--
-- Name: metadata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: anboxcloud
--

ALTER SEQUENCE public.metadata_id_seq OWNED BY public.metadata.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: anboxcloud
--

CREATE TABLE public.schema_migrations (
    version bigint NOT NULL,
    dirty boolean NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO anboxcloud;

--
-- Name: users; Type: TABLE; Schema: public; Owner: anboxcloud
--

CREATE TABLE public.users (
    id integer NOT NULL,
    age integer NOT NULL,
    username character varying(255) NOT NULL,
    email public.citext NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO anboxcloud;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: anboxcloud
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO anboxcloud;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: anboxcloud
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: games id; Type: DEFAULT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.games ALTER COLUMN id SET DEFAULT nextval('public.games_id_seq'::regclass);


--
-- Name: metadata id; Type: DEFAULT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.metadata ALTER COLUMN id SET DEFAULT nextval('public.metadata_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: anboxcloud
--

COPY public.games (id, title, description, url, age_rating, publisher, created_at, updated_at) FROM stdin;
1	assasins creed	killing templar in the middle age and fiding a strange golden fruit	https://www.ubisoft.com/fr-fr/	18	ubisoft	2022-10-27 04:34:58.036094+00	2022-10-27 04:34:58.036094+00
2	assasinscreed	killing templar in the middle age and fiding a strange golden fruit	https://www.ubisoft.com/fr-fr/	18	ubisoft	2022-10-27 04:55:11.976879+00	2022-10-27 04:55:11.976879+00
3	summonerwars	Summoners War is one of the classic gacha RPGs. It’s been around for a long time, and that means it’s matured a lot more than a lot of the other games in the genre.	https://sw.com2us.com/en	7	sw	2022-10-27 06:20:26.661842+00	2022-10-27 06:20:26.661842+00
4	apex legends	Apex Legends Mobile came out in 2022 and hit the ground running. It’s a battle royale shooter in the same genre as Fortnite and PUBG New State.	https://www.ea.com/games/apex-legends	12	ea	2022-10-27 06:21:35.407821+00	2022-10-27 06:21:35.407821+00
5	callofduty	Call of Duty: Mobile was our pick for the best Android game in 2019. We usually wait a while before adding a game, but Call of Duty: Mobile is so intensely popular with such a high rating that we added it more quickly than usual.	https://www.callofduty.com/fr/mobile	16	activision	2022-10-27 06:22:41.813005+00	2022-10-27 06:22:41.813005+00
6	genshin impact	Genshin Impact is an action RPG game with gacha mechanics. The game was also our pick for the best game of 2020.	https://genshin.hoyoverse.com/en/	12	genshin	2022-10-27 06:23:35.543848+00	2022-10-27 06:23:35.543848+00
7	leagueoflegends	League of Legends: Wild Rift is a 5v5 MOBA game.	https://wildrift.leagueoflegends.com/en-us/	16	riotgames	2022-10-27 06:24:47.950425+00	2022-10-27 06:24:47.950425+00
8	callofduty	modified callofduty description	https://modifiedcallofdutyurl.com	21	activision	2022-10-27 06:25:45.697334+00	2022-10-27 06:28:01.417843+00
10	pokemon go	Play with pokemon on reaL LIFE WITH ANDROID !	https://pokemongolive.com/	7	nintendo	2022-10-27 06:31:06.357362+00	2022-10-27 06:31:06.357362+00
11	Un jeu pas beau	liwehwefkuifhg	http://wefwefwef	0	kwuhgkuwf	2022-10-27 09:11:04.509562+00	2022-10-27 09:11:04.509562+00
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: public; Owner: anboxcloud
--

COPY public.metadata (id, player_id, played_game_id, play_time, created_at, updated_at) FROM stdin;
3	1	7	7896	2022-10-27 07:27:40.442035+00	2022-10-27 09:11:24.759997+00
2	1	10	6570	2022-10-27 07:26:58.33622+00	2022-10-27 09:11:24.761133+00
1	12	8	9094	2022-10-27 06:51:07.33468+00	2022-10-27 09:11:24.761976+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: anboxcloud
--

COPY public.schema_migrations (version, dirty) FROM stdin;
4	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: anboxcloud
--

COPY public.users (id, age, username, email, password_hash, created_at, updated_at) FROM stdin;
1	24	root	gabriel.mougard@gmail.com	$2a$10$mGQ6AZPwxbYKS/S4JQzsp.qzVbHOK0QZj/Wb2T7.dwKxjNIBaqKQy	2022-10-27 03:55:03.281924+00	2022-10-27 03:55:03.281924+00
4	1	root2	gabriel.mougard2@gmail.com	$2a$10$1JVdiCw6LCtd.SBNnpqC4uFcgiS8ofFE/MF98.LxI8zzVYJm6COle	2022-10-27 03:56:36.61615+00	2022-10-27 03:56:36.61615+00
5	24	jeanpaul	jean.paul@gmail.com	$2a$10$pFDqnoWI7slaZmC9FcHN3.TkoIr31E1hI6e3BtfJOCpsWWTXc8WJq	2022-10-27 04:27:38.915887+00	2022-10-27 04:27:38.915887+00
6	12	meerarowley	meera.rowley@gmail.com	$2a$10$VwYI6Ts0QBDVJbVXoJ/3S.dnvpUg5PMh3b/WQ27GvKsN6FBnOuTDq	2022-10-27 06:13:41.984611+00	2022-10-27 06:13:41.984611+00
7	16	jarvisreid	jarvis.reid@gmail.com	$2a$10$gbjXwU2vK0wBm1OHISE/Z.lPpI3rf2XhojyYLceqoabdXhenoXqX.	2022-10-27 06:14:20.767707+00	2022-10-27 06:14:20.767707+00
8	6	bradenfeeney	bradenfeeney@gmail.com	$2a$10$bE1OB.g5qs5D/j655p21GejOmRO7uMuK0aoYdI/25SQtb8OBNqHrm	2022-10-27 06:14:50.29954+00	2022-10-27 06:14:50.29954+00
9	33	clarencevazquez	clarencevazquez@gmail.com	$2a$10$v98/M/SKQ4qyPYJXroRWlucV7hrIih.IqFIB8GQJYCr3aWyxQGkA6	2022-10-27 06:15:32.673177+00	2022-10-27 06:15:32.673177+00
10	14	ritawest	ritawest@gmail.com	$2a$10$CR9PezoFHrzv.2apEWJgmuwAG7NVZhGaal1VcYKCJTAQxmlOJxUYi	2022-10-27 06:16:07.053839+00	2022-10-27 06:16:07.053839+00
11	15	alyssiamonaghan	alyssiamonaghan@gmail.com	$2a$10$kvWK97kx05OZ/uLFGq.Wdum6k9A7kZtH1Lhln0nw4S3dZACPvuF.i	2022-10-27 06:16:31.464686+00	2022-10-27 06:16:31.464686+00
13	20	rhiannelson	rhiannelson@gmail.com	$2a$10$QE7VS4rCbATR3xMQax/PJeTYo1PHROWzL5ixKPoPbeq7RKM.y9Wbe	2022-10-27 06:17:21.574769+00	2022-10-27 06:17:21.574769+00
14	21	eliotttalbot	eliotttalbot@gmail.com	$2a$10$7tMN2gWsFno4lJ8Ndg.1U.mdimWXwcdjSdTKOTV/fTPRXm8VICZ5S	2022-10-27 06:17:44.41983+00	2022-10-27 06:17:44.41983+00
15	7	lyndonstubbs	lyndonstubbs@gmail.com	$2a$10$M6voWceTCn3uR4GEhhqDseahm5s3OJGW3KylW0DyHEuoRDXbLq/I2	2022-10-27 06:18:07.442724+00	2022-10-27 06:18:07.442724+00
12	23	jovanpatrick	jovanpatrick@gmail.com	$2a$10$XlQEwx5HtH.h59ZLQgHgJeDHHssB.9n4y1iynlkbjUq43Xs.7QWAS	2022-10-27 06:16:57.995594+00	2022-10-27 06:37:26.424854+00
16	2	tructruc123	truc.truc@gmail.com	$2a$10$WA.1azK0.jGrs1rRVjFgTecYnZ/qalY2Ed2iSeLkLbHvd35v9Fw26	2022-10-27 09:09:12.526627+00	2022-10-27 09:09:12.526627+00
\.


--
-- Name: games_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anboxcloud
--

SELECT pg_catalog.setval('public.games_id_seq', 11, true);


--
-- Name: metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anboxcloud
--

SELECT pg_catalog.setval('public.metadata_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: anboxcloud
--

SELECT pg_catalog.setval('public.users_id_seq', 16, true);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id);


--
-- Name: metadata metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.metadata
    ADD CONSTRAINT metadata_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: metadata fk_game; Type: FK CONSTRAINT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.metadata
    ADD CONSTRAINT fk_game FOREIGN KEY (played_game_id) REFERENCES public.games(id) ON DELETE CASCADE;


--
-- Name: metadata fk_player; Type: FK CONSTRAINT; Schema: public; Owner: anboxcloud
--

ALTER TABLE ONLY public.metadata
    ADD CONSTRAINT fk_player FOREIGN KEY (player_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

